//NOTE: We put these in another file because make greps through evaluate.h for these strings.
#define EvalFileDefaultNameBig "nn-37f18f62d772.nnue"
#define EvalFileDefaultNameSmall ""
