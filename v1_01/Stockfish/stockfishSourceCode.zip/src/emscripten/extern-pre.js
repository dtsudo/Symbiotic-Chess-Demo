(function () {
var Stockfish;
function INIT_ENGINE() {
