var Module = {
  print: function(stdout) {
    postMessage(stdout);
  }
};
