/*!
 * Stockfish copyright T. Romstad, M. Costalba, J. Kiiski, G. Linscott
 * and other contributors.
 *
 * Multi-variant support by Daniel Dugovic and contributors:
 * https://github.com/ddugovic/Stockfish
 *
 * Released under the GNU General Public License v3.
 *
 * Compiled to JavaScript and Webassembly by Niklas Fiekas
 * <niklas.fiekas@backscattering.de> using Emscripten and Binaryen.
 *
 * https://github.com/niklasf/stockfish.js
 */

